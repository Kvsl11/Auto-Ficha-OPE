attr = 'submodule'
class A:
    attr = 'submodule'
