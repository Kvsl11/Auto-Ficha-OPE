attr = 'submodule'
class A:
    attr = 'submodule'
class submodule:
    attr = 'rebound'
    class B:
        attr = 'rebound'
