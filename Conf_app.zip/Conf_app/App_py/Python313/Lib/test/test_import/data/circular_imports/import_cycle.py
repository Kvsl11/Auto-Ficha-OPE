import test.test_import.data.circular_imports.import_cycle as m

m.some_attribute
