import test.test_import.data.circular_imports.subpkg2.parent

test.test_import.data.circular_imports.subpkg2.parent
